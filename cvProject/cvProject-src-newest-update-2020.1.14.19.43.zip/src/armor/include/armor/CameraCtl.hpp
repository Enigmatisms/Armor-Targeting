/**
 * file CameraCtl.hpp
 * The CameraCtl Class for using hikvision camera in opencv easily.
 * by Dinger
 * complement: hqy
 * last change: 2019.12.13
 */

#ifndef __CAMERA_CTL_HPP
#define __CAMERA_CTL_HPP

#include <stdio.h>
#include <string.h>
#include "MvCameraControl.h"
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/types_c.h>
#include <unistd.h>

//using namespace cv;

#define MAX_IMAGE_DATA_SIZE   (40*1024*1024)
#define DEFAULT_ENEMY_IS_RED cv::Scalar(2400, 0, 0)
#define DEFAULT_ENEMY_IS_BLUE cv::Scalar(0, 0, 2400)

enum GAIN_MODE{NONE=0, ONCE=1, CONTINUOUS=2};
enum BITRATE{               //kbps
    DEFAULT =4096,          //默认码率4096kbps
    HIGH    =6144,           
    ULTRA   =8192, 
    MAXIMUM =16383,         //Hikvision sdk能接受的最大码率
    MEDIUM  =2048, 
    LOW     =1024,
    MINIMUM =128            //最小码率
    };

class CameraCtl
{
private:
    int nRet;
    void* handle;
    unsigned char * pData;                                  //与取流相关
    bool grabing;
    bool printDeviceInfo(MV_CC_DEVICE_INFO* pstMVDevInfo);  //显示设备信息
    cv::VideoWriter writer;
public:
    CameraCtl();
    ~CameraCtl();
    int startGrabbing();                                    //开始取流
    int stopGrabbing();                                     //停止取流
    cv::Mat getOpencvMat(int Msec=1000);                    //转换为OpenCV cv::Mat格式
    int setExposureTime(const float t=10000.0);             //设置自动曝光时间
    int setGainMode(GAIN_MODE enumMode=NONE);               //设置自动增益模式
    int getGainMode(bool disp=false);                       //获取自动增益模式
    int setGain(const float gain);                          //设置增益值
    int setFrameRate(const float rate=60.0);                //设置帧率
    int setAutoExposure(const unsigned int mode);           //设置自动曝光模式
    int getAutoExposure(bool disp=false);                   //查询当前自动曝光模式
    int loadFeature(const char *path);                      //(不支持)读取设置
    int saveFeature(const char *path);                      //(不支持)保存设置
    float getExposureTime(bool disp=false);                 //获取曝光时间
    float getGain(bool disp=false);                         //获取当前增益值
    float getFrameRate(bool disp=false);                    //获取当前帧率
    float getGamma(bool disp=false);                        //获取当前gamma值
    int getSaturation(bool disp=false);                     //获取画面饱和度（好像没用）
    int setSaturation(const int sat);                       //设置画面饱和度（好像没用）
    int getBGRBalance(cv::Scalar &input);                   //获取当前画面白平衡
    int setBGRBalance(cv::Scalar bgr=DEFAULT_ENEMY_IS_BLUE);//设置画面白平衡
};

bool CameraCtl::printDeviceInfo(MV_CC_DEVICE_INFO* pstMVDevInfo)
{
    if (NULL == pstMVDevInfo){
        printf("%s\n" , "The Pointer of pstMVDevInfoList is NULL!");
        return false;
    }
    if (pstMVDevInfo->nTLayerType == MV_GIGE_DEVICE){               //网络设备调用
		// 打印当前相机ip和用户自定义名字
		// print current ip and user defined name
        printf("%s %x\n" , "nCurrentIp:" , pstMVDevInfo->SpecialInfo.stGigEInfo.nCurrentIp);                   //当前IP
        printf("%s %s\n" , "chUserDefinedName:" , pstMVDevInfo->SpecialInfo.stGigEInfo.chUserDefinedName);     //用户定义名
    }
    else if (pstMVDevInfo->nTLayerType == MV_USB_DEVICE){           //usb设备调用
        printf("UserDefinedName:%s\n", pstMVDevInfo->SpecialInfo.stUsb3VInfo.chUserDefinedName);
    }
    else{
        printf("Not supported.\n");
    }
    return true;
}

CameraCtl::CameraCtl() {
    nRet = MV_OK;
    handle = NULL;
    pData = new unsigned char [MAX_IMAGE_DATA_SIZE];
    grabing = false;
    MV_CC_DEVICE_INFO_LIST stDeviceList;
    memset(&stDeviceList, 0, sizeof(MV_CC_DEVICE_INFO_LIST));

    // 枚举设备
	// enum device
    nRet = MV_CC_EnumDevices(MV_GIGE_DEVICE | MV_USB_DEVICE, &stDeviceList);
    if (MV_OK != nRet) {
        printf("MV_CC_EnumDevices failed! nRet [%x]\n", nRet);
        return;
    }
    unsigned int nIndex = 0;
    if (stDeviceList.nDeviceNum > 0) {
        for (int i = 0; i < stDeviceList.nDeviceNum; i++) {
            printf("[device %d]:\n", i);
            MV_CC_DEVICE_INFO* pDeviceInfo = stDeviceList.pDeviceInfo[i];
            if (NULL == pDeviceInfo) {
                break;
            }
            printDeviceInfo(pDeviceInfo);
        }
    } 
    else {
        printf("Find No Device!\n");
        return;
    }
    // 选择设备并创建句柄
	// select device and create handle
    nRet = MV_CC_CreateHandle(&handle, stDeviceList.pDeviceInfo[0]);
    if (MV_OK != nRet) {
        printf("MV_CC_CreateHandle failed! nRet [%x]\n", nRet);
        return;
    }

    // 打开设备
	// open device
    nRet = MV_CC_OpenDevice(handle);
    if (MV_OK != nRet){
        printf("MV_CC_OpenDevice failed! nRet [%x]\n", nRet);
        return;
    }
    
	nRet = MV_CC_SetEnumValue(handle, "TriggerMode", 0);
    if (MV_OK != nRet){
        printf("MV_CC_SetTriggerMode failed! nRet [%x]\n", nRet);
        return;
    }
}

CameraCtl::~CameraCtl() {
    if (grabing)
        stopGrabbing();
	if (pData) {
		delete pData;	
		pData = NULL;
	}
    // 销毁句柄
	// destroy handle
    nRet = MV_CC_DestroyHandle(handle);
    if (MV_OK != nRet){
        printf("MV_CC_DestroyHandle fail! nRet [%x]\n", nRet);
    }
}

int CameraCtl::startGrabbing() {
    // 开始取流
	// start grab image
    nRet = MV_CC_StartGrabbing(handle);
    if (MV_OK != nRet){
        printf("MV_CC_StartGrabbing fail! nRet [%x]\n", nRet);
        return -1;
    }
    grabing = true;
    return 0;
}

int CameraCtl::stopGrabbing() {
    // 停止取流
	// end grab image
    nRet = MV_CC_StopGrabbing(handle);
    if (MV_OK != nRet) {
        printf("MV_CC_StopGrabbing failed! nRet [%x]\n", nRet);
        return -1;
    }
    grabing = false;
    return 0;
}

cv::Mat CameraCtl::getOpencvMat(int Msec) {
	MV_FRAME_OUT_INFO_EX stImageInfo = {0};
    memset(&stImageInfo, 0, sizeof(MV_FRAME_OUT_INFO_EX));
    unsigned int nDataSize = MAX_IMAGE_DATA_SIZE;

	nRet = MV_CC_GetImageForBGR(handle, pData, nDataSize, &stImageInfo, Msec);
    cv::Mat img;
	if (nRet == MV_OK) {
		// (stImageInfo.enPixelType == PixelType_Gvsp_BGR8_Packed)
		img = cv::Mat(stImageInfo.nHeight, stImageInfo.nWidth, CV_8UC3, pData);
	} else {
        printf("MV_CC_GetImage failed!\n");
    }
    return img;
}

int CameraCtl::setExposureTime(const float t){             //设置曝光时间
        nRet=MV_CC_SetExposureTime(handle, t);
        if(nRet != MV_OK){
            printf("Failed to set exposure time. nRet [%x]\n", nRet);
            return -1;
        }
        return 0;
    }

int CameraCtl::setGainMode(GAIN_MODE enumMode){               //设置自动增益
    nRet=MV_CC_SetGainMode(handle, enumMode);
    if(nRet != MV_OK){
        printf("Failed to set gain mode. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}               

int CameraCtl::getGainMode(bool disp){                       //获取自动增益信息,正常值0,1,2
    //disp选项：是否打印信息
    MVCC_ENUMVALUE* pstValue=new MVCC_ENUMVALUE;
    nRet=MV_CC_GetGainMode(handle, pstValue);
    int res=0;
    if(nRet != MV_OK){
        printf("Get gain mode failed. nRet [%x]\n", nRet);
        printf("Exception: %x.\n", nRet);
        delete pstValue;
        return -1;
    }
    if(disp){
        printf("Current mode:%d. ", pstValue->nCurValue);
        switch(pstValue->nCurValue){
            case 0: printf("Auto gain is not set up.\n");break;
            case 1: printf("Auto gain is triggered once.\n");break;
            case 2: printf("Continuous auto gain.\n");break;
            default: printf("Unknown parameter.\n"); delete pstValue; return -1;
        }
    }
    res = pstValue->nCurValue;
    delete pstValue;
    return res;
}       

int CameraCtl::setGain(const float gain){                          //设置固定值自动增益
    nRet=MV_CC_SetGain(handle, gain);
    if(nRet != MV_OK){
        printf("Failed to set gain. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}       

int CameraCtl::setFrameRate(const float rate){                //设置相机帧率
    nRet=MV_CC_SetFrameRate(handle, rate);
    if(nRet != MV_OK){
        printf("Failed to set frame rate. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}

int CameraCtl::setAutoExposure(const unsigned int mode){           //设置自动曝光
    if(mode>2){
        printf("Input param error: digit should be in range(0,3).\n");
        return -1;
    }
    nRet=MV_CC_SetExposureAutoMode(handle, mode);
    if(nRet != MV_OK){
        printf("Failed to set auto exposure mode. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}

int CameraCtl::getAutoExposure(bool disp){                   //获取自动曝光信息，正常为0,1,2
    //disp选项：是否打印信息
    MVCC_ENUMVALUE* tmp=new MVCC_ENUMVALUE;
    int res;
    nRet=MV_CC_GetExposureAutoMode(handle, tmp);
    if(nRet != MV_OK){
        printf("Fail to get auto exposure mode info. nRet [%x]\n", nRet);
        delete tmp;
        return -1;
    }
    if(disp){
        printf("Current mode:%d. ", tmp->nCurValue);
        if(tmp->nCurValue==1){
            printf("Auto exposure: ONCE.\n");
        }
        else if(!tmp->nCurValue){
            printf("Auto exposure: OFF.\n");
        }
        else if(tmp->nCurValue==2){
            printf("Auto exposure: CONTINUOUS.\n");
        }
        else printf("Unknown status.\n");
    }
    res = tmp->nCurValue;
    delete tmp;
    return res;
}

int CameraCtl::loadFeature(const char *path){                       //加载相机参数设置  
    nRet=MV_CC_FeatureLoad(handle, path);
    if(nRet != MV_OK){
        printf("Failed to load camera features. You may check your filepath. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}

int CameraCtl::saveFeature(const char *path){                       //保存相机参数设置
    nRet=MV_CC_FeatureSave(handle, path);
    if(nRet != MV_OK){
        printf("Failed to save camera features. You may check your filepath. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}

float CameraCtl::getExposureTime(bool disp){                 //返回曝光时间,正常值为正数
    //disp选项：是否打印信息
    MVCC_FLOATVALUE *tmpF=new MVCC_FLOATVALUE;
    nRet=MV_CC_GetExposureTime(handle, tmpF);
    float res;
    if(nRet != MV_OK){
        printf("Fail to get exposure time. nRet [%x]\n", nRet);
        delete tmpF;
        return -1;
    }
    if(disp){
        printf("Current exposure time: %f.\n", tmpF->fCurValue);
        printf("With minimum value:%f, and maxinum value:%f.\n",
            tmpF->fMin, tmpF->fMax);
    }
    res=tmpF->fCurValue;
    delete tmpF;
    return res;
}     

float CameraCtl::getGain(bool disp){                         //返回当前增益值,正常值非负
    //disp选项：是否打印信息    
    MVCC_FLOATVALUE *tmpF=new MVCC_FLOATVALUE;
    nRet=MV_CC_GetGain(handle, tmpF);
    float res;
    if(nRet != MV_OK){
        printf("Fail to get gain. nRet [%x]\n", nRet);
        delete tmpF;
        return -1;
    }
    if(disp){
        printf("Current gain: %f.\n", tmpF->fCurValue);
        printf("With minimum value:%f, and maxinum value:%f.\n",
            tmpF->fMin, tmpF->fMax);
    }
    res=tmpF->fCurValue;
    delete tmpF;
    return res;
}

float CameraCtl::getFrameRate(bool disp){                    //获取相机帧率,正常为正数
    //disp选项：是否打印信息
    MVCC_FLOATVALUE *tmpF=new MVCC_FLOATVALUE;
    nRet=MV_CC_GetFrameRate(handle, tmpF);
    float res;
    if(nRet != MV_OK){
        printf("Fail to get frame rate. nRet [%x]\n", nRet);
        delete tmpF;
        return -1;
    }
    if(disp){
        printf("Current frame rate: %f.\n", tmpF->fCurValue);
        printf("With minimum value:%f, and maxinum value:%f.\n",
            tmpF->fMin, tmpF->fMax);
    }
    res=tmpF->fCurValue;
    delete tmpF;
    return res;
} 

float CameraCtl::getGamma(bool disp){
    MVCC_FLOATVALUE *tmpF=new MVCC_FLOATVALUE;
    nRet=MV_CC_GetGamma(handle, tmpF);
    if(nRet != MV_OK){
        printf("Failed to load gamma info. nRet [%x]\n", nRet);
        return -1;
    }
    if(disp){
        printf("Current gamma rate: %f.\n", tmpF->fCurValue);
        printf("With minimum value:%f, and maxinum value:%f.\n",
            tmpF->fMin, tmpF->fMax);
    }
    double res=tmpF->fCurValue;
    delete tmpF;
    return res;
}

int CameraCtl::getSaturation(bool disp){                     //获取饱和度信息
    MVCC_INTVALUE *tmpI=new MVCC_INTVALUE;
    nRet=MV_CC_GetSaturation(handle, tmpI);
    int res=0;
    if(nRet != MV_OK){
        printf("Get saturation failed. nRet [%x]\n", nRet);
        printf("Exception: %x.\n", nRet);
        delete tmpI;
        return -1;
    }
    else{
        if(disp){
            printf("Current gain: %d.\n", tmpI->nCurValue);
            printf("With minimum value:%d, and maxinum value:%d.\n",
            tmpI->nMin, tmpI->nMax);
        }
        res=tmpI->nCurValue;
    }
    delete tmpI;
    return res;
}

int CameraCtl::setSaturation(const int sat){                       //设置饱和度信息
    nRet=MV_CC_SetSaturation(handle, sat);
    if(nRet != MV_OK){
        printf("Failed to set saturation. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}

int CameraCtl::getBGRBalance(cv::Scalar &input){                       //取出白平衡值，入参：BGR通道的cv::Scalar值
    MVCC_INTVALUE *tmp=new MVCC_INTVALUE;
    nRet=MV_CC_GetBalanceRatioBlue(handle, tmp);
    if(nRet != MV_OK){
        printf("Get blue channel failed. nRet [%x]\n", nRet);
        printf("Exception: %x.\n", nRet);
        delete tmp;
        return -1;
    }
    input[0]=tmp->nCurValue;
    nRet=MV_CC_GetBalanceRatioGreen(handle, tmp);
    if(nRet != MV_OK){
        printf("Get green channel failed. nRet [%x]\n", nRet);
        printf("Exception: %x.\n", nRet);
        delete tmp;
        return -1;
    }
    input[1]=tmp->nCurValue;
    nRet=MV_CC_GetBalanceRatioGreen(handle, tmp);
    if(nRet != MV_OK){
        printf("Get red channel failed. nRet [%x]\n", nRet);
        printf("Exception: %x.\n", nRet);
        delete tmp;
        return -1;
    }
    input[2]=tmp->nCurValue;
    return 0;
}

int CameraCtl::setBGRBalance(cv::Scalar bgr){    //设置白平衡值
    nRet=MV_CC_SetBalanceRatioBlue(handle, bgr[0]);
    nRet=MV_CC_SetBalanceRatioGreen(handle, bgr[1]);
    nRet=MV_CC_SetBalanceRatioRed(handle, bgr[2]);
    if(nRet != MV_OK){
        printf("Failed to set balance ratio. nRet [%x]\n", nRet);
        return -1;
    }
    return 0;
}

#endif // __CAMERA_CTL_HPP
